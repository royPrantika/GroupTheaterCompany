package grouptheatercompany;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ViewLeaveApplicationController implements Initializable {

    @FXML
    private TextField viewTextField;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void BackButtonOnClick(ActionEvent event) throws IOException {
        Parent scene2;
        scene2 = FXMLLoader.load(getClass().getResource("Producer.fxml"));
        Scene scene3 = new Scene(scene2);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene3);
        window.show();
    }

    @FXML
    private void ViewLeaveApplicationButtonOnClick(ActionEvent event) {
        /* 
        viewTextField.clear();
        File f= null;
        Scanner sc;
        String str;
        String[] tokens;
        try{
            f = new File("Accountofficerleave.txt");
            sc = new Scanner(f);
            if(f.exists()){
                viewTextField.appendText("leave application from account officer\n");
                while(sc.hasNextLine()){
                    str = sc.nextLine();
                    tokens = str.split(",");
                    viewTextField.appendText(
                     "Name ="+tokens[0]+
                             ", ID ="+tokens[1]+
                             ", degi ="+tokens[2]+
                             ", From ="+tokens[3]+
                             ", To ="+tokens[4]+
                             ", Short Reason ="+tokens[5]+"\n"
                    
                    );
                }
            }
             else 
                viewTextField.setText("oops! Does not have any leave application");
        } 
        catch (IOException ex) {
            Logger.getLogger(ViewLeaveApplicationController.class.getName()).log(Level.SEVERE, null, ex);
        } 
        finally {
            
        }     
         */

        viewTextField.setText("");
        File f = null;
        FileInputStream fis = null;
        ObjectInputStream ois = null;

        try {
            f = new File("LeaveApplicationObjects.bin");
            fis = new FileInputStream(f);
            ois = new ObjectInputStream(fis);
            EmployeeLeaveApplication emp;
            try {
                viewTextField.setText("");
                while (true) {

                    emp = (EmployeeLeaveApplication) ois.readObject();

                    viewTextField.appendText(emp.toString());
                }
            } catch (Exception e) {
                //
            }
            //  viewTextField.appendText(" \n");            
        } catch (IOException ex) {
        } finally {
            try {
                if (ois != null) {
                    ois.close();
                }
            } catch (IOException ex) {
            }
        }

    }
}
