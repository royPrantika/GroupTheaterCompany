package grouptheatercompany;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

public class CreateProjectBudgetSceneController implements Initializable {

    @FXML
    private TextField PerformerCostTextField;
    @FXML
    private TextField ConstructionLaborCostTextField;
    @FXML
    private TextField EquipmentRentalCostTextField;
    @FXML
    private TextField SoundSystemCostTextField;
    @FXML
    private TextField LocationRentTextField;
    @FXML
    private TextField OtherexpensesTextField;
    @FXML
    private TextField ViewBudgetTextField;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void BackButtonOnClick(ActionEvent event) throws IOException {
         Parent scene2;
        scene2 = FXMLLoader.load(getClass().getResource("Producer.fxml"));
        Scene scene3 = new Scene(scene2);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(scene3);
        window.show();
    }

    @FXML
    private void SendButtonOnClick(ActionEvent event) {
        File f = null;
        FileWriter fw = null;
        FileChooser fc = null;

        try {
            f = new File("CreateProjectBudget.txt");
            if (f.exists()) {
                fw = new FileWriter(f, true);
            } else {
                fw = new FileWriter(f);
            }

            fw.write(
                    PerformerCostTextField.getText() + ","
                    + ConstructionLaborCostTextField.getText() + ","
                    + EquipmentRentalCostTextField.getText() + ","
                    + SoundSystemCostTextField.getText() + ","
                    + LocationRentTextField.getText() + ","
                    + OtherexpensesTextField.getText() + "\n"
            );

        } catch (IOException ex) {
            Logger.getLogger(CreateProjectBudgetSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (fw != null) {
                    fw.close();
                }
            } catch (IOException ex) {
                Logger.getLogger(CreateProjectBudgetSceneController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Information Alert");
        a.setHeaderText("Successful!!");
        a.setContentText("project budget has been sent successfully ");
        a.showAndWait();
    }

    @FXML
    private void PreviewbudgetButtonOnClick(ActionEvent event) {
        ViewBudgetTextField.clear();
        File f = null;
        Scanner sc;
        String str;
        String[] tokens;
        try {
            f = new File("CreateProjectBudget.txt");
            sc = new Scanner(f);
            if (f.exists()) {
                ViewBudgetTextField.appendText("Project budget from Producer \n");
                while (sc.hasNextLine()) {
                    str = sc.nextLine();
                    tokens = str.split(",");
                    ViewBudgetTextField.appendText(
                            "Performer cost =" + tokens[0]
                            + ", Cost for set construction labor =" + tokens[1]
                            + ", Equipment rental =" + tokens[2]
                            + ", sound system cost =" + tokens[3]
                            + ", location rent: =" + tokens[4]
                            + ", Other expenses  =" + tokens[5] + "\n"
                    );
                }
            } else {
                ViewBudgetTextField.setText("oops! 404 not found ");
            }
        } catch (IOException ex) {
            Logger.getLogger(CreateProjectBudgetSceneController.class.getName()).log(Level.SEVERE, null, ex);
        } finally {

        }

    }

}
